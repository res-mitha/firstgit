a = 2
n = 3

result = 1

for i in range(n):
    result = result * a

print(result)
