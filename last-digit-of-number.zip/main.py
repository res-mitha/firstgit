
n=int(input("enter the number:"))
a=n%10
print(a)