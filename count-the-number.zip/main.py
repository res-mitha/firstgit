n=int(input("enter the number:"))
count=0
while(n!=0):
    d=n%10
    count+=1
    n=n//10
    
print(count)



